## ------------------------------------------------------------------------
library(QPackage)

## ------------------------------------------------------------------------
t <- tuple("title" = "This is a title", "brand" = "Product brand")

# print the class
print(class(t))

# print contents of t
# title
print(t$title)
# brand
print(t$brand)

## ------------------------------------------------------------------------
# Get the path of bowker.csv file that is included along with the package
bowker_file_path <- system.file("extdata/books", "bowker.csv", package = "QPackage")
# Use read_csv to read the contents of csv file
bowker <- read_csv(bowker_file_path, status = read_status)

# print the status
print(read_status) #0 success, 1 error

# print the class
class(bowker)


## ------------------------------------------------------------------------
# Display colnames of bowker
colnames(bowker)
# check whether "id" can be set as key attribute
is_id <- check_id(bowker, list("id")) # 0 success, 1 error
# print the result
print(is_id)

## ------------------------------------------------------------------------
# set "id" as key attribute
exit_status <- set_id(bowker, list("id"))
print(exit_status) # 0 success, 1 error
print(bowker@key)

## ------------------------------------------------------------------------
data(bowker_bk_dataset)
data(walmart_bk_dataset)

## ------------------------------------------------------------------------
# assign to different variable
walmart <- walmart_bk_dataset
bowker <- bowker_bk_dataset

# print the class
class(bowker)

# print key attribute
print(bowker@key)

## ------------------------------------------------------------------------
#View(bowker)

## ------------------------------------------------------------------------
# block attributes from walmart and bowker dataset 
attr1 <- "isbn" # from walmart dataset
attr2 <- "isbn" # from bowker dataset

# do blocking
cand_set <- apply_block(walmart, bowker, attr_equiv_block, attr1, attr2, 
                        col_names_a = list("title", "author", "binding", "publisher", "pages"), 
                        col_names_b = list("title", "author", "binding", "publisher", "pages")
                        )
# number of rows in candidate set
nrow(cand_set)

# attributes in candidate set
colnames(cand_set)

## ------------------------------------------------------------------------
sample_data <- sample_qtable(cand_set, 25)

## ------------------------------------------------------------------------
show_builtin_simfuns()
show_builtin_tokenizers()

## ------------------------------------------------------------------------
feature_list <- create_features(walmart, bowker, 
                                list(c("title", "title"), 
                                     c("numAuthors", "numAuthors"), 
                                     c("binding", "binding")))
length(feature_list)

## ------------------------------------------------------------------------
print(feature_list[[2]])

## ------------------------------------------------------------------------
test_list <- create_features(walmart, bowker, 
                                list(c("title", "title"), 
                                     c("numAuthors", "numAuthors"), 
                                     c("binding", "binding")), 
                                list("jaccard"), list("tok_qgram"))

length(test_list)
print(test_list)

## ------------------------------------------------------------------------
# ignore this command -- done only for illustration
data(test_label_cset) # this should not be executed.

labeled_feat_vec <- convert_to_feature_vecs(walmart, bowker, label_cset, feature_list)

# print column names
colnames(labeled_feat_vec)

# print first row
labeled_feat_vec[1, ]

## ------------------------------------------------------------------------
# Models compared : rpart, randomForest, SVM
# do 10 fold cross validation

# install.packages("rpart")  ## required to install rpart
library(rpart)
acc_dt <- cv_kfold(labeled_feat_vec, 10, rpart, predict_args = list(type = "class"))

acc_dt

#install.packages("randomForest") ## required to install randomFores
library(randomForest) 
acc_rf <- cv_kfold(labeled_feat_vec, 10, randomForest)

acc_rf

# install.packages("e1071") ## required to install e1071
library(e1071)
acc_svm <- cv_kfold(labeled_feat_vec, 10, svm)

acc_svm


## ------------------------------------------------------------------------
model <- train_model(labeled_feat_vec, randomForest)

## ------------------------------------------------------------------------
candset_feat_vec <- convert_to_feature_vecs(walmart, bowker, cand_set, feature_list)
candset_fv_with_labels<- predict_label(candset_feat_vec, model)

colnames(candset_fv_with_labels)

